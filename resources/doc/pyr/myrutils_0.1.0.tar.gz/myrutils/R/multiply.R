#' Multiply two numbers
#'
#' This function multiplies two numbers.
#'
#' @param x The first number.
#' @param y The second number.
#' @return The product of x and y.
#'
#' @examples
#' multiply(2, 3)
#'
#' @export
multiply <- function(x, y) {
    prod <- x * y
    return(prod)
}
